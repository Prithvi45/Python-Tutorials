from django.http import HttpResponse
from django.views.generic import TemplateView,ListView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.core.urlresolvers import reverse_lazy
from django.views.generic.edit import ModelFormMixin
from Course.models import Server,ServerClusterMapping

class ServerList(ListView):
    model = Server

class ServerCreate(CreateView):
    model = Server
    success_url = reverse_lazy('server_list')
    fields = '__all__'

    def form_valid(self, form):
        self.object = form.save(commit=False)
        self.object.save()

        for cluster in form.cleaned_data['clusters']:
            membership = ServerClusterMapping()
            membership.cluster = cluster
            membership.server = self.object
            membership.sequence = 155
            membership.save()
        return super(ModelFormMixin, self).form_valid(form)


class ServerUpdate(UpdateView):
    model = Server
    success_url = reverse_lazy('server_list')
    fields = ['name', 'ip', 'order']

class ServerDelete(DeleteView):
    model = Server
    success_url = reverse_lazy('server_list')

# from django.views.generic.edit import ModelFormMixin
# from django.views.generic import CreateView
# from .models import Cluster, ServerClusterMapping

# class ClusterList(ListView):
#     model = Cluster

# class ClusterCreate(CreateView):
#     model = Cluster
#     fields = '__all__'

#     def form_valid(self, form):
#         self.object = form.save(commit=False)
#         for server in form.cleaned_data['servers']:
#             membership = ServerClusterMapping()
#             membership.cluster = self.object
#             membership.server = server
#             membership.sequence = 11
#             membership.save()
#         return super(ModelFormMixin, self).form_valid(form)



