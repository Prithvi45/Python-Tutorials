from django.db import models

from django.core.urlresolvers import reverse

class Cluster(models.Model):
    title = models.CharField(max_length=100)
    

class Server(models.Model):
    name = models.CharField(max_length=200)
    ip = models.GenericIPAddressField()
    order = models.IntegerField()
    clusters = models.ManyToManyField(Cluster, through='ServerClusterMapping')

    def __unicode__(self):
        return self.name

    def get_absolute_url(self):
        return reverse('server_edit', kwargs={'pk': self.pk})

class ServerClusterMapping(models.Model):
    cluster = models.ForeignKey(Cluster)
    server = models.ForeignKey(Server)
    sequence = models.IntegerField()