from django.contrib import admin
from .models import *

admin.site.register(Server)
admin.site.register(Cluster)
admin.site.register(ServerClusterMapping)