from django.forms import Form,ModelForm
from .models import Video
from django import forms
import betterforms
from betterforms.multiform import MultiModelForm

class VideoCourseForm(ModelForm):
	class Meta:
		model = Video 
		fields = '__all__'

class VideoCourseInfo(Form):
	position = forms.IntegerField()

class VideoCourseMapping(ModelForm):
	class Meta:
		model = ResourceCourseMapping
		fields = '__all__'

class VideoCourseSeq(MultiModelForm):
	from_classes = {
	    'video': VideoCourseForm,
	    'course': VideoCourseMapping,
	}