from datetime import date
from django.db import models
from django.template.defaultfilters import slugify

from taggit.managers import TaggableManager


class Product(models.Model):
    name = models.CharField(max_length=255)
    slug = models.SlugField(max_length=255, blank=True)
    sku = models.CharField(max_length=255, blank=True, null=True)
    description = models.TextField()
    price = models.DecimalField(decimal_places=2, max_digits=10)
    active = models.BooleanField(default=True)
    featured = models.BooleanField(default=False)
    weight = models.DecimalField(
        max_digits=8, decimal_places=2, null=True, blank=True)
    height = models.DecimalField(
        max_digits=8, decimal_places=2, null=True, blank=True)
    date_added = models.DateField(null=True, blank=True)

    tags = TaggableManager()

    def __str(self):
        return self.name

    # def save(self, kwargs):
    #     if not self.pk:
    #         self.date_added = date.today()

    #     if self.name and not self.slug:
    #         self.slug = slugify(self.name)

    #     if not self.sku:
    #         self.sku = self.slug
    #     super(Product, self).save(kwargs)