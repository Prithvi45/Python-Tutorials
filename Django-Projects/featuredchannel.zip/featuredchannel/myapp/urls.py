from django.conf.urls import *

from .views import ProductDetail, ProductIndex, TagIndexView

urlpatterns = [
    url(r'^$', ProductIndex.as_view(), name='products'),
    url(r'^tag/(?P<slug>[-\w]+)/$', TagIndexView.as_view(), name='tagged'),
    url(
        r'^(?P<pk>\d+)-(?P<slug>[-\w]+)/$', ProductDetail.as_view(),
        name='product'),
]