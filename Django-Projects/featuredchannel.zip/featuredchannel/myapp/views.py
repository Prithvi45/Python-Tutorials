from django.shortcuts import render

from django.views.generic import DetailView, ListView

from taggit.models import Tag

from .models import Product


class TagMixin(object):
    def get_context_data(self):
        context = super(TagMixin, self).get_context_data()
        context['tags'] = Tag.objects.all()
        return context

class ProductDetail(DetailView):
    template_name = 'detail.html'
    context_object_name = 'product'
    model = Product


class ProductIndex(TagMixin, ListView):
    template_name = 'index.html'
    model = Product
    paginate_by = '10'
    queryset = Product.objects.all()
    context_object_name = 'products'

class TagIndexView(TagMixin, ListView):
    template_name = 'index.html'
    model = Product
    paginate_by = '10'
    context_object_name = 'products'

    def get_queryset(self):
        return Product.objects.filter(tags__slug=self.kwargs.get('slug'))
